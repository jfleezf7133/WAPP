lscloud-theme-barcelona
=======================

LemonStand Cloud Barcelona Theme

Created by: LemonStand eCommerce Inc. 

Demo Store: https://barcelona.lemonstand.com/

This work is licensed under a Creative Commons Attribution-NoDerivatives 4.0 International License

http://creativecommons.org/licenses/by-nd/4.0/

![Barcelona Theme](https://raw.githubusercontent.com/lemonstand/lscloud-theme-barcelona/master/resources/images/barcelona-screen.png)

Barcelona – is a clean, fashion and modern HTML/CSS Template for your LemonStand cloud store! User friendly and simple for customers.


## Template features and options

* Responsive

* Made based on Bootstrap 3

* Valid HTML5

* Clean and Modern Design

* CSS3 Animations

* Valid HTML5 Markup

* Crossbrowser 
  
* And much more…  
